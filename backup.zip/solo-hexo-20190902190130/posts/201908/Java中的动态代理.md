title: Java 中的动态代理
date: '2019-08-18 17:09:13'
updated: '2019-08-18 17:13:13'
tags: [待分类]
permalink: /articles/2019/08/18/1566119352940.html
---
![](https://img.hacpai.com/bing/20180414.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 代理（Proxy）
利用代理可以在运行时创建一个实现了一组指定接口的新类，这个类具有以下方法：
* 指定接口所拥有的所有方法。
* Object 类的全部方法，例如 toString()、equals()等。

但是，无法在运行过程中定义这些方法的新代码，必须构造调用处理器（`InvocationHandler`）来处理
```

public interface InvocationHandler {

    public Object invoke(Object proxy, Method method, Object[] args)
        throws Throwable;
}

```
接口中只定义了一个方法`invoke`，无论何时通过代理对象调用接口中的方法，`invoke`方法都会被调用，并向其传递调用的方法与参数，然后由调用处理器决定方法的调用方式。

## 代理对象（`com.sun.proxy.$Proxy0`）
所有的代理对象都扩展自`Proxy`，这个类只有一个非静态实例域，所有的代理类都重写了 Object 的 toString()、hashCode()、equals() 方法，其他与原类一致。对于特定的类加载器与同一组接口只能有一个代理类，也就是说调用`newProxyInstance`两次并传入同样的参数，那么就创建了同一个类的两个实例化对象。

```
// Proxy.java
package java.lang.reflect;

protected InvocationHandler h;

public static Object newProxyInstance(ClassLoader loader, Class<?>[] interfaces, InvocationHandler h)
```
Proxy.newProxyInstance()方法可以创建一个代理对象，这个方法有三个参数：
* 类加载器（`class loader`）
* 代理类实现的接口，是一个Class对象数组（`Class[]`）
* 调用处理器（`InvocationHandler`的实现类）

## 代理的作用与用途
代理的特性决定了新创建的代理类能够在方法调用前后插入用户自定义的代码而无需关心方法内部的实现，因此常被用于以下几个方面：
* 路由对远程服务器的方法调用。
* 在程序运行期间，将用户接口事件与动作关联起来。（常用于AOP）
* 以调试的目的跟踪方法的调用。

### 作用举例
现有接口`IPerson`
```
package com.zhaiyanqi.proxy;

public interface IPerson {

    void eat();

    void run();

    void sleep();
}
```
实现了接口的类`Person`
```
package com.zhaiyanqi.proxy;

public class Person implements IPerson {

    @Override
    public void eat() {
        System.out.println("eating...");
    }

    @Override
    public void run() {
        System.out.println("running...");
    }

    @Override
    public void sleep() {
        throw new RuntimeException(); // 执行sleep方法会抛出异常
    }
}
```
自定义调用处理器`MyHandler`,类中定义了三个方法`onBefore`、`onFinish()`、`onError()`在调用invoke时分别调用，可以实现在类运行时打印类调用的信息与错误信息。
```
package com.zhaiyanqi.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;

public class MyHandler implements InvocationHandler {

    private Object object;

    public Object newProxyObject(Object obj) {
        this.object = obj;

        return Proxy.newProxyInstance(obj.getClass().getClassLoader(), obj.getClass().getInterfaces(), this);
    }


    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

        Object obj = null;
        try{
            onBefore(method, args);
            obj = method.invoke(object, args);
            onFinish(method, args);
        } catch (Exception e) {
            onError(method, args);
        }

        System.out.println();
        return obj;
    }

    private void onBefore(Method method, Object[] args) {
        System.out.println("before:" + object.getClass().getSimpleName() +
                " invoke " + method.getName() + ", parm:"+Arrays.toString(args));
    }

    private void onError(Method method, Object[] args){
        System.out.println("error: when " + object.getClass().getSimpleName() + " invoke " + method.getName() + ", there was something wrong, parm:"+Arrays.toString(args));
    }

    private void onFinish(Method method, Object[] args){
        System.out.println("finish:" + object.getClass().getSimpleName() + " invoke " + method.getName()+ ", parm:"+Arrays.toString(args));
    }
}

```
运行与结果
```
    public static void main(String[] args) {
        Person person = new Person();
        MyHandler handler = new MyHandler();
        IPerson p = (IPerson) handler.newProxyObject(person);
        p.eat();
        p.run();
        p.sleep();
    }
```
运行结果
> before:Person invoke eat, parm:null
eating...
finish:Person invoke eat, parm:null

>before:Person invoke run, parm:null
running...
finish:Person invoke run, parm:null

>before:Person invoke sleep, parm:null
error: when Person invoke sleep, there was something wrong, parm:null
Process finished with exit code 0

可以看到在类调用接口中的方法时，能够分别在调用前、调用后与抛出异常时进行日志打印，这也就是面向切面编程的基本原理（`AspectOrientedProgramming`）：将日志记录，性能统计，安全控制，事务处理，异常处理等代码从业务逻辑代码中划分出来，通过对这些行为的分离，我们希望可以将它们独立到非指导业务逻辑的方法中，进而改变这些行为的时候不影响业务逻辑的代码。

