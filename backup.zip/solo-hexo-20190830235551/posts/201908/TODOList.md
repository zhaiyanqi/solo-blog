title: TODO List
date: '2019-08-15 13:11:03'
updated: '2019-08-21 16:17:38'
tags: [待分类]
permalink: /articles/2019/08/15/1565845863536.html
---
![](https://img.hacpai.com/bing/20190111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

* HashMap TreeMap HashSet TreeSet
* MySQL 索引的实现方式 为何无法命中索引 索引的底层实现
* HTTP 1.0 1.1 2.0 传输超大文件 http是不是有连接的
* Spring Bean 装载方式
* 用户态 内核态 中断 线程间通信 进程间通信
* 泛型与泛型擦除
* B树 B+树 红黑树
* 为什么Redis是单线程的，性能却很高
* Redis 是如何保证高可用的 主从复制 
* Mysql 主从复制 高可用
* Redis 中5中数据类型的底层实现
* Linux 命令 kill -9的作用
* 数据库的最左前缀原则
* RPC 如何实现 作用 等等 常用的框架
* 什么是零拷贝
* epoll
* 全双工和半双工的区别

## 面试笔试算法题
* 
