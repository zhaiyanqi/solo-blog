title: 谈谈 Redis
date: '2019-08-13 16:18:13'
updated: '2019-08-13 16:42:07'
tags: [待分类]
permalink: /articles/2019/08/13/1565684293475.html
---
![](https://img.hacpai.com/bing/20181026.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

Redis 是一种 C 语言编写的，支持网络，基于内存亦可持久化存储的，Key-Value 型非关系数据库。具有很高的性能，并支持五种数据类型（Sting、set、zset、hash、list）

## Redis和Memcache区别
两者都是非关系型 KV 数据库，主要有以下一些不同：
1. Memcache 只支持1 MB 大小的 value，key 最大为250个字符。Redis 最大支持512 MB 的key。
2. Redis 支持灾后的文件恢复，从宕机后恢复时能保证数据的完好。而Memcache是纯内存数据库，关机后数据会丢失，不支持数据的持久化。
3. Redis 支持多种数据类型，Memcache 只支持 Key-Value 形式的数据。
4. Redis支持主从结构，一主多从或者一从舵主。
5. 整体来看，Redis 是一种功能较为全面的数据库，而Memcache只是一种内存缓存。Redis的应用场景比较丰富，也可做消息队列。Memcache 吞吐量强于 Redis ，可以利用多核优势。

## Redis 的内存回收策略
Resdis 也会由于内存不足而出现错误，因此特殊的内存回收策略还是需要的。通常情况下，Redis 会使用 LRU 作为默认的内存回收策略，这也是 Memcached 的默认行为。从Redis 4.0开始，系统采用 LFU（Least Frequently Used）的内存回收策略。

### Maxmemory 配置命令
`Maxmemory`命令用于配置数据集能够使用多少内存。可以通过修改`redis.conf`文件来实现内存大小的配置，或者在 Redis 运行后通过`CONFIG SET`命令修改最大内存。例如，给Redis设置100MB的内存限制，可以在`redis.conf`文件中添加以下代码
```
maxmemory 100mb
```
设置 maxmemory 的值为 0 代表不进行内存限制，初始化时64 位系统不进行内存限制，32 位系统有 3GB 的默认内存限制。
当达到默认的最大内存限制时，可以通过设置不同的策略来是系统产生不同的处理方式，弹出错误或者进行内存回收以便于系统满足制定的内存限制。
### 回收策略
可以通过`maxmemory-policy`命令来修改内存
* **noeviction**：当达到内存限制并且客户端尝试执行可能导致使用更多内存的命令时返回错误（大多数写命令，但[DEL](https://redis.io/commands/del)和一些例外）。
* **allkeys-lru**：首先尝试删除最近使用较少的（LRU）密钥来逐出密钥，以便为添加的新数据腾出空间。
* **volatile-lru**：首先尝试删除最近使用较少的（LRU）密钥，然后仅在具有**过期集的**密钥中删除密钥，以便为添加的新数据腾出空间。
* **allkeys-random**：**随机**逐出密钥，以便为添加的新数据腾出空间。
* **volatile-random**：**随机**逐出密钥以便为添加的新数据腾出空间，但只驱逐带有**过期集的**密钥。
* **volatile-ttl**：用**过期集**驱逐密钥，并尝试先用较短的生存时间（TTL）驱逐密钥，以便为添加的新数据腾出空间。

该政策**挥发性-LRU**，**挥发性随机**和**挥发性-TTL**的行为很像**noeviction**如果没有钥匙驱逐匹配的先决条件。
